/**
 * The GameBoard Class stores the requisite data, moves, and updates Piece[][] pieceLocation data
 * field where the information is stored for any given game.
 */
public class GameBoard {
    Piece[][] pieceLocation = new Piece[5][5];

    /**
     * @param row a positive int, must be between 0 and 4 or it will cause a nullPointerException error
     * @param column a positive int, must be between 0 and 4 or it will cause a nullPointerException error
     * @return a Piece object representing a specific location on the game board.
     */
    public Piece getSquare(int row, int column) {return pieceLocation[row][column];}

    /**
     * @param color must be either "Blue", "Green", "Yellow", or "Red". Any other String will always return false.
     * @return a boolean whether or not it has found a flag Piece or a pawn Piece with the associated flag color.
     * It stops when a flag of the chosen color has been found.
     */
    public boolean getFlag(String color) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (pieceLocation[i][j] != null) {
                    Piece selectedPiece = pieceLocation[i][j];
                    if (selectedPiece.isFlag() && selectedPiece.getFlagColor().equals(color)) return true;
                    else if (selectedPiece.isPawnWithFlag() && selectedPiece.getFlagColor().equals(color)) return true;
                }
            }
        }
        return false;
    }

    /**
     * @param die1 any int value.
     * @param die2 any int value.
     * @return if one of the two int values int die1 and int die2 have a difference of 2 or greater the method
     * returns true, otherwise it returns false.
     */
    public boolean capturePiece(int die1, int die2) {
        int largerDie;
        int smallerDie;
        boolean captures = false;
        if (die1 > die2) {largerDie = die1; smallerDie = die2;} else {largerDie = die2; smallerDie = die1;}
        if (largerDie - smallerDie >= 2) captures = true;
        return captures;
    }

    /**
     * @param selectedPiece a Piece object, used to determine its color, if it is a pawn with a flag,
     *                     and other data as needed.
     * @param startRow The starting row where the selectedPiece was, must be between 0 and 4
     * @param startColumn The starting column where the selectedPiece was, must be between 0 and 4
     * @param endRow The desired row that the piece is to be moved to, endRow must be -1, 0, or 1 when subtracted
     *              from startRow or the method will return false
     * @param endColumn The desired column that the piece is to be moved to, endColumn must be -1, 0, or 1 when
     *                 subtracted from start column or the method will return false.
     * @param die1 If a piece exists in the desired square a value must be taken to know whether the piece captures
     *            or not by using the capturePiece() method
     * @param die2 If a piece exists in the desired square a value must be taken to know whether the piece captures
     *            or not by using the capturePiece() method
     * @return true or false depending on whether the move is considered to be valid. If a piece attempts to capture
     * a piece but fails the method will not move the piece but will return true.
     * startColumn - endColumn and startRow - endRow must both have a non 0 sum and a 0 sum between the
     * two of them or the method will return false.
     */
    public boolean movePiece(Piece selectedPiece, int startRow, int startColumn, int endRow, int endColumn,
                             int die1, int die2) {
        if ((startRow - endRow <= 1 && startRow - endRow >= -1) &&
                (startColumn - endColumn <= 1 && startColumn - endColumn >= -1) &&
                (startRow - endRow == 0 ^ startColumn - endColumn == 0)) {
            if (pieceLocation[endRow][endColumn] != null) {
                // if the piece moved to is a flag
                if (pieceLocation[endRow][endColumn].isFlag) {
                    String color = pieceLocation[endRow][endColumn].getFlagColor();
                    if (selectedPiece.getPawnColor().equals(color) && !(selectedPiece.isPawnWithFlag)) {
                        if (selectedPiece.getPawnColor().equals("Blue") && endRow != 0 && endColumn != 2
                                && pieceLocation[0][2] == null) {
                            pieceLocation[0][2] = new Piece("Blue");
                            remove(endRow, endColumn);
                            return true;
                        } else if (selectedPiece.getPawnColor().equals("Green") && endRow != 2 && endColumn != 4
                                && pieceLocation[2][4] == null) {
                            pieceLocation[2][4] = new Piece("Green");
                            remove(endRow, endColumn);
                            return true;
                        } else if (selectedPiece.getPawnColor().equals("Yellow") && endRow != 4 && endColumn != 2
                                && pieceLocation[4][2] == null) {
                            pieceLocation[4][2] = new Piece("Yellow");
                            remove(endRow, endColumn);
                        } else if (selectedPiece.getPawnColor().equals("Red") && endRow != 2 && endColumn != 0
                                && pieceLocation[2][0] == null) {
                            pieceLocation[2][0] = new Piece("Red");
                            remove(endRow, endColumn);
                        } else {
                            return false;
                        }
                    } else if (selectedPiece.isPawnWithFlag && selectedPiece.getPawnColor().equals(color)) {
                        checkAndRemoveFlag(selectedPiece, endRow, endColumn);
                        return true;
                    } else {
                        pieceLocation[endRow][endColumn] = selectedPiece;
                        selectedPiece.setPawnWithFlag(true);
                        selectedPiece.setFlagColor(color);
                        remove(startRow, startColumn);
                        return true;
                    }
                    // if the piece is a pawn
                } else if (capturePiece(die1, die2)) {
                    if (pieceLocation[endRow][endColumn].isPawnWithFlag) {
                        String color = pieceLocation[endRow][endColumn].getFlagColor();
                        pieceLocation[endRow][endColumn] = selectedPiece;
                        remove(startRow, startColumn);
                        switch (color) {
                            case "Blue" :
                                if (pieceLocation[0][2] != null) {
                                    pieceLocation[startRow][startColumn] = selectedPiece;
                                }
                                pieceLocation[0][2] = new Piece("Blue");
                                break;
                            case "Green" :
                                if (pieceLocation[2][4] != null) {
                                    pieceLocation[startRow][startColumn] = selectedPiece;
                                }
                                pieceLocation[2][4] = new Piece("Green");
                                break;
                            case "Yellow" :
                                if (pieceLocation[4][2] != null) {
                                    pieceLocation[startRow][startColumn] = selectedPiece;
                                }
                                pieceLocation[4][2] = new Piece("Yellow");
                                break;
                            case "Red" :
                                if (pieceLocation[2][0] != null) {
                                    pieceLocation[startRow][startColumn] = selectedPiece;
                                }
                                pieceLocation[2][0] = new Piece("Red");
                                break;
                        }
                    } else {
                        String color = pieceLocation[endRow][endColumn].getPawnColor();
                        if (selectedPiece.pawnColor.equals(color)) {
                            System.out.println("Invalid move");
                            return false;
                        } else {
                            pieceLocation[endRow][endColumn] = selectedPiece;
                            remove(startRow, startColumn);
                        }
                    }
                    return true;
                }
            } else {
                if (selectedPiece.isPawnWithFlag) {
                    checkAndRemoveFlag(selectedPiece, endRow, endColumn);
                }
                pieceLocation[endRow][endColumn] = selectedPiece;
                remove(startRow, startColumn);
            }
            return true;
        } else return false;
    }

    /**
     * @param color must be either "Blue", "Green", "Yellow", or "Red". If it is not, the method will return a 0
     * @return a positive int value, it is expected that the value should be either 0, 1, 2, or 3.
     */
    public int pieceCount(String color) {
        int count = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (getSquare(i, j) != null)
                if (pieceLocation[i][j].isPawn && pieceLocation[i][j].getPawnColor().equals(color)) count++;
            }
        }
        return count;
    }

    /**
     * Sets the pieceLocation data field for a 4 player game.
     */
    public void setPieceLocationGameStart4Player() {
        Piece bluePiece1 = new Piece("Blue", false);
        Piece bluePiece2 = new Piece("Blue", false);
        Piece bluePiece3 = new Piece("Blue", false);
        Piece blueFlag = new Piece("Blue");

        Piece greenPiece1 = new Piece("Green", false);
        Piece greenPiece2 = new Piece("Green", false);
        Piece greenPiece3 = new Piece("Green", false);
        Piece greenFlag = new Piece("Green");

        Piece yellowPiece1 = new Piece("Yellow", false);
        Piece yellowPiece2 = new Piece("Yellow", false);
        Piece yellowPiece3 = new Piece("Yellow", false);
        Piece yellowFlag = new Piece("Yellow");

        Piece redPiece1 = new Piece("Red", false);
        Piece redPiece2 = new Piece("Red", false);
        Piece redPiece3 = new Piece("Red", false);
        Piece redFlag = new Piece("Red");

        // add specific pieces
        pieceLocation[0][1] = bluePiece1;
        pieceLocation[0][2] = blueFlag;
        pieceLocation[1][2] = bluePiece2;
        pieceLocation[0][3] = bluePiece3;

        pieceLocation[1][4] = greenPiece1;
        pieceLocation[2][3] = greenPiece2;
        pieceLocation[2][4] = greenFlag;
        pieceLocation[3][4] = greenPiece3;

        pieceLocation[3][2] = yellowPiece1;
        pieceLocation[4][1] = yellowPiece2;
        pieceLocation[4][2] = yellowFlag;
        pieceLocation[4][3] = yellowPiece3;

        pieceLocation[1][0] = redPiece1;
        pieceLocation[2][0] = redFlag;
        pieceLocation[2][1] = redPiece2;
        pieceLocation[3][0] = redPiece3;
    }

    /**
     * sets the pieceLocation data field for a 2 player game between blue and yellow
     */
    public void setPieceLocationGameStart2Player() {
        Piece bluePiece1 = new Piece("Blue", false);
        Piece bluePiece2 = new Piece("Blue", false);
        Piece bluePiece3 = new Piece("Blue", false);
        Piece blueFlag = new Piece("Blue");

        Piece yellowPiece1 = new Piece("Yellow", false);
        Piece yellowPiece2 = new Piece("Yellow", false);
        Piece yellowPiece3 = new Piece("Yellow", false);
        Piece yellowFlag = new Piece("Yellow");

        pieceLocation[0][1] = bluePiece1;
        pieceLocation[0][2] = blueFlag;
        pieceLocation[1][2] = bluePiece2;
        pieceLocation[0][3] = bluePiece3;

        pieceLocation[3][2] = yellowPiece1;
        pieceLocation[4][1] = yellowPiece2;
        pieceLocation[4][2] = yellowFlag;
        pieceLocation[4][3] = yellowPiece3;
    }

    /**
     * @param color a string value, do not use any other color that isn't "Blue", "Green", "Yellow", or "Red".
     * @param row a positive int between 0 and 4. Any other int will cause an ArrayOutOfBounds error
     * @param column a positive int between 0 and 4. Any other int will cause an ArrayOutOfBounds error
     * This method adds a pawn to the pieceLocation data field.
     */
    public void addPiece(String color, int row, int column) {pieceLocation[row][column] = new Piece(color, false);}

    /**
     * @param selectedPiece a Piece that appears on the pieceLocation data field. This method is called during
     *                      the movePiece() method and uses the Piece object that is inputted their
     * @param endRow an int value between 0 and 4, any other value will cause an ArrayOutOfBounds error
     * @param endColumn an int value between 0 and 4, any other value will cause an ArrayOutOfBounds error
     * if the selectedPiece is a certain color and reaches a certain location inside the pieceLocation
     * data field, such as a blue piece with an enemy flag moves to (0, 2), then the method removes the selected
     * flag and calls the removeTeam() method to remove the eliminated team.
     */
    public void checkAndRemoveFlag(Piece selectedPiece, int endRow, int endColumn) {
        //if blue captures a flag
        if (selectedPiece.getPawnColor().equals("Blue")) {
            if (endRow == 0 && endColumn == 2) {
                String flagColor = selectedPiece.getFlagColor();
                selectedPiece.setPawnWithFlag(false);
                selectedPiece.setFlagColor(null);
                removeTeam(flagColor);
            }
        }
        //if green captures a flag
        if (selectedPiece.getPawnColor().equals("Green")) {
            if (endRow == 2 && endColumn == 4) {
                String flagColor = selectedPiece.getFlagColor();
                selectedPiece.setPawnWithFlag(false);
                selectedPiece.setFlagColor(null);
                removeTeam(flagColor);
            }
        }
        //if yellow captures a flag
        if (selectedPiece.getPawnColor().equals("Yellow")) {
            if (endRow == 4 && endColumn == 2) {
                String flagColor = selectedPiece.getFlagColor();
                selectedPiece.setPawnWithFlag(false);
                selectedPiece.setFlagColor(null);
                removeTeam(flagColor);
            }
        }
        //if red captures a flag
        if (selectedPiece.getPawnColor().equals("Red")) {
            if (endRow == 2 && endColumn == 0) {
                String flagColor = selectedPiece.getFlagColor();
                selectedPiece.setPawnWithFlag(false);
                selectedPiece.setFlagColor(null);
                removeTeam(flagColor);
            }
        }
    }

    /**
     * @param row an int value between 0 and 4, any other value will result in an ArrayOutOfBounds error
     * @param column an int value between 0 and 4, any other value will result in an ArrayOutOfBounds error
     */
    public void remove(int row, int column) {pieceLocation[row][column] = null;}

    /**
     * @param color must be either "Blue", "Green", "Yellow", or "Red". The method will not do anything for any
     *             other color
     */
    public void removeTeam(String color) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (pieceLocation[i][j] != null) {
                    Piece selectedPiece = pieceLocation[i][j];
                    if (selectedPiece.isPawnWithFlag() && selectedPiece.getPawnColor().equals(color)) {
                        String flagColor = selectedPiece.getFlagColor();
                        pieceLocation[i][j] = new Piece(flagColor);
                    } else if (selectedPiece.isPawn() && selectedPiece.getPawnColor().equals(color)) remove(i, j);
                }
            }
        }
    }
}