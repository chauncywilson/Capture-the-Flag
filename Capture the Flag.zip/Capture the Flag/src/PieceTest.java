import org.junit.Test;

public class PieceTest {
    @Test
    public void getPawnColor() {
        Piece validPiece = new Piece("Blue", false);
        assert validPiece.getPawnColor().equals("Blue");
    }

    @Test
    public void getFlagColor() {
        Piece validPiece = new Piece("Yellow");
        Piece validPawn = new Piece("Blue", true);
        validPawn.setFlagColor("Yellow");
        assert validPiece.getFlagColor().equals("Yellow");
        assert validPawn.getFlagColor().equals("Yellow");
    }

    @Test
    public void isPawnTest() {
        Piece pawn = new Piece("Green", true);
        Piece flag = new Piece("Red");

        assert pawn.isPawn();
        assert (!(flag.isPawn));
    }

    @Test
    public void isFlagTest() {
        Piece flag = new Piece("Yellow");
        Piece pawn = new Piece("Green", true);

        assert flag.isFlag();
        assert (!(pawn.isFlag()));
    }

    @Test
    public void isPawnWithFlagTest() {
        Piece pawn1 = new Piece("Green", false);
        Piece pawn2 = new Piece("Red", true);

        assert (!(pawn1.isPawnWithFlag()));
        assert pawn2.isPawnWithFlag();
    }
}
