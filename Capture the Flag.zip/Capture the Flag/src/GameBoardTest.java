import org.junit.Test;

public class GameBoardTest extends GameBoard {
    @Test
    public void testGetSquare() {
        Piece piece = new Piece("Blue", false);
        pieceLocation[0][0] = piece;
        assert getSquare(0, 0) == piece;
    }

    @Test
    public void testGetFlag() {
        Piece flag = new Piece("Yellow");
        pieceLocation[3][2] = flag;
        assert getFlag("Yellow");
    }

    @Test
    public void testCapturePiece() {
        int die1 = 3;
        int die2 = 4;

        assert !(capturePiece(die1, die2));
    }

    @Test
    public void testMovePiece() {
        Piece piece = new Piece("Blue", false);
        pieceLocation[4][4] = piece;

        assert movePiece(piece, 4, 4, 4, 3, 2, 5);
    }

    @Test
    public void testPieceCount() {
        setPieceLocationGameStart2Player();
        assert pieceCount("Blue") == 3;
    }
}
