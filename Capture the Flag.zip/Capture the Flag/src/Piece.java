/**
 * The Piece class creates both the flags and the pawns inside this project. It contains data fields for
 * the following; boolean isPawn, boolean isFlag, boolean, isPawnWithFlag, String pawnColor, and String flagColor
 */
public class Piece {
    boolean isPawn;
    boolean isFlag;
    boolean isPawnWithFlag;
    String pawnColor;
    String flagColor;

    /**
     * @param flagColor must be a String one of the following colors "Blue", "Green", "Yellow", or "Red".
     * This constructor is the flag constructor of the Piece class, use the other constructor for pawns.
     */
    Piece(String flagColor){
        setFlag(true);
        if (flagColor.equals("Blue") || flagColor.equals("Green") || flagColor.equals("Yellow")
                || flagColor.equals("Red")) setFlagColor(flagColor);
        else System.out.println("Error: Unknown color entered");
    }

    /**
     * @param color must be a String of one of the following colors "Blue", "Green", "Yellow", or "Red".
     * @param isPawnWithFlag a non null boolean, for this project, it is called to be false unless otherwise stated
     */
    Piece(String color, boolean isPawnWithFlag) {
        setPawn(true);
        setFlag(false);
        if (color.equals("Blue") || color.equals("Green") || color.equals("Yellow") || color.equals("Red"))
            setPawnColor(color);
        else {System.out.println("Error: Unknown color entered");}
        setPawnWithFlag(isPawnWithFlag);
    }

    /**
     * @return pawnColor of the object.
     */
    public String getPawnColor() {return pawnColor;}

    /**
     * @return flagColor of the object
     */
    public String getFlagColor() {return flagColor;}

    /**
     * @return a boolean if the object isPawn
     */
    public boolean isPawn() {return isPawn;}

    /**
     * @return a boolean if the object isFlag
     */
    public boolean isFlag() {return isFlag;}

    /**
     * @return a boolean if the object isFlag
     */
    public boolean isPawnWithFlag() {return isPawnWithFlag;}

    /**
     * @param pawn Setter method for the isPawn data field
     */
    public void setPawn(boolean pawn) {isPawn = pawn;}

    /**
     * @param flag Setter method for the isFlag data field
     */
    public void setFlag(boolean flag) {isFlag = flag;}

    /**
     * @param color Setter method for the pawnColor data field. String color must be "Blue", "Green", "Yellow", or "Red"
     */
    public void setPawnColor(String color) {
        if (color.equals("Blue") || color.equals("Green") || color.equals("Yellow") || color.equals("Red"))
            this.pawnColor = color;
        else System.out.println("Error: Unknown color entered");
    }

    /**
     * @param color Setter method for the flagColor data field. String color must be "Blue", "Green", "Yellow", or "Red"
     */
    public void setFlagColor(String color) {
        if (color.equals("Blue") || color.equals("Green") || color.equals("Yellow") || color.equals("Red"))
            this.flagColor = color;
        else System.out.println("Error: Unknown color entered");
    }

    /**
     * @param pawnWithFlag Setter method for the isPawnWithFlag data field
     */
    public void setPawnWithFlag(boolean pawnWithFlag) {isPawnWithFlag = pawnWithFlag;}
}

