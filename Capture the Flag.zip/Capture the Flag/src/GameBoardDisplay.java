import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.util.ArrayList;

/**
 * @author student Chauncy Wilson
 * @version 1.0.0
 *
 * The new game of Capture the Flag. Fight off your opponents by relying on a combination of strategy and luck.
 * Do you have what it takes to defeat your opponents and be the last one standing?
 *
 * This is the main class to run. It contains the GUI elements and manipulates data from other classes. This project
 * was built using SDK 1.8 for Java
 */
public class GameBoardDisplay extends Application {
    GameBoard gameBoard = new GameBoard();
    GridPane piecePlacement = new GridPane();

    Label die1 = makeDiceLabel();
    Label die2 = makeDiceLabel();
    Label turn = new Label("Yellow");
    Label UITurn = new Label("Turn: ");
    Label explanation = new Label();

    Label labelA = new Label("A");
    Label labelB = new Label("B");
    Label labelC = new Label("C");
    Label labelD = new Label("D");
    Label labelE = new Label("E");
    Label label1 = new Label("1");
    Label label2 = new Label("2");
    Label label3 = new Label("3");
    Label label4 = new Label("4");
    Label label5 = new Label("5");

    Circle nPossibleMove = makePossibleMove();
    Circle ePossibleMove = makePossibleMove();
    Circle sPossibleMove = makePossibleMove();
    Circle wPossibleMove = makePossibleMove();

    ArrayList<Integer> moves = new ArrayList<>();

    /**
     * @param primaryStage Used to run JavaFX. Required to implement the abstract class Application.
     *
     * This method contains 4 lambda expressions that manipulate the scene and various panes, 2 to set up for
     *        either a 2 player game or a 4 player game, the other 2 handle the movement actions and
     *        placing new pieces onto the board
     */
    @Override
    public void start(Stage primaryStage) {
        setFontRow(labelA);
        setFontRow(labelB);
        setFontRow(labelC);
        setFontRow(labelD);
        setFontRow(labelE);
        setFontColumn(label1);
        setFontColumn(label2);
        setFontColumn(label3);
        setFontColumn(label4);
        setFontColumn(label5);

        GridPane gameBoardDisplay = new GridPane();
        gameBoardDisplay.setPadding(new Insets(40));
        setBoard(gameBoardDisplay);
        gameBoardDisplay.addRow(5, labelA, labelB, labelC, labelD, labelE);
        gameBoardDisplay.addColumn(5, label1, label2, label3, label4, label5);

        piecePlacement.setPadding(new Insets(40));

        turn.setFont(new Font(25));
        UITurn.setFont(new Font(25));
        UITurn.setPadding(new Insets(5));

        explanation.setFont(new Font(25));
        explanation.setPadding(new Insets(5));

        Button placePieceButton = new Button("Place a piece");

        //2 player game button
        Button playersButton2 = new Button("2 Player Game");
        playersButton2.setPadding(new Insets(0, 20, 0, 0));

        //4 player game button and event
        Button playersButton4 = new Button("4 Player Game");
        playersButton4.setPadding(new Insets(0, 20, 0, 0));
        playersButton4.setOnAction(event -> {
            gameBoardDisplay.getChildren().removeAll(playersButton2, playersButton4);

            //add blue pieces
            piecePlacement.add(makeBluePiece(), 1, 0);
            piecePlacement.add(makeBluePiece(), 3, 0);
            piecePlacement.add(makeBluePiece(), 2, 1);

            //add yellow pieces
            piecePlacement.add(makeYellowPiece(), 1, 4);
            piecePlacement.add(makeYellowPiece(), 2, 3);
            piecePlacement.add(makeYellowPiece(), 3, 4);

            //add green pieces
            piecePlacement.add(makeGreenPiece(), 3, 2);
            piecePlacement.add(makeGreenPiece(), 4, 1);
            piecePlacement.add(makeGreenPiece(), 4, 3);

            //add red pieces
            piecePlacement.add(makeRedPiece(), 0, 1);
            piecePlacement.add(makeRedPiece(), 1, 2);
            piecePlacement.add(makeRedPiece(), 0, 3);

            //add flags
            piecePlacement.add(makeBlueFlag(), 2, 0);
            piecePlacement.add(makeGreenFlag(), 4, 2);
            piecePlacement.add(makeYellowFlag(), 2, 4);
            piecePlacement.add(makeRedFlag(), 0, 2);

            //add dice
            Group dice1 = new Group(makeDice(), die1);
            Group dice2 = new Group(makeDice(), die2);

            piecePlacement.add(makeFakeInset(), 5, 0);
            piecePlacement.add(placePieceButton, 6, 0);
            gameBoardDisplay.add(dice1, 6, 1);
            gameBoardDisplay.add(dice2, 7, 1);
            gameBoardDisplay.add(UITurn, 6, 3);
            gameBoardDisplay.add(turn, 7, 3);
            gameBoardDisplay.add(explanation, 6, 4);

            gameBoard.setPieceLocationGameStart4Player();
        });

        playersButton2.setOnAction(event -> {
            gameBoardDisplay.getChildren().removeAll(playersButton2, playersButton4);

            //add blue pieces
            piecePlacement.add(makeBluePiece(), 1, 0);
            piecePlacement.add(makeBluePiece(), 3, 0);
            piecePlacement.add(makeBluePiece(), 2, 1);

            //add yellow pieces
            piecePlacement.add(makeYellowPiece(), 1, 4);
            piecePlacement.add(makeYellowPiece(), 2, 3);
            piecePlacement.add(makeYellowPiece(), 3, 4);

            piecePlacement.add(makeBlueFlag(), 2, 0);
            piecePlacement.add(makeYellowFlag(), 2, 4);

            piecePlacement.addRow(2, makePlaceHolder(), makePlaceHolder(), makePlaceHolder(),
                    makePlaceHolder(),makePlaceHolder());
            piecePlacement.addColumn(0, makePlaceHolder(), makePlaceHolder(), makePlaceHolder(),
                    makePlaceHolder(),makePlaceHolder());
            piecePlacement.addColumn(4, makePlaceHolder(), makePlaceHolder(), makePlaceHolder(),
                    makePlaceHolder(),makePlaceHolder());
            //add dice
            Group dice1 = new Group(makeDice(), die1);
            Group dice2 = new Group(makeDice(), die2);

            piecePlacement.add(makeFakeInset(), 5, 0);
            piecePlacement.add(placePieceButton, 6, 0);
            gameBoardDisplay.add(dice1, 6, 1);
            gameBoardDisplay.add(dice2, 7, 1);
            gameBoardDisplay.add(UITurn, 6, 3);
            gameBoardDisplay.add(turn, 7, 3);
            gameBoardDisplay.add(explanation, 6, 4);

            gameBoard.setPieceLocationGameStart2Player();
        });

        placePieceButton.setOnAction(event -> {
            //if center square is empty
            if (gameBoard.getSquare(2, 2) == null && gameBoard.pieceCount(turn.getText()) < 3) {
                switch (turn.getText()) {
                    case "Blue" :
                        piecePlacement.getChildren().remove(getNodeByRowColumnIndex(2, 2, piecePlacement));
                        piecePlacement.add(makeBluePiece(), 2, 2);
                        gameBoard.addPiece(turn.getText(), 2, 2);
                        explanation.setText("B@C-3");
                        nextTurn();
                        break;
                    case "Green" :
                        piecePlacement.getChildren().remove(getNodeByRowColumnIndex(2, 2, piecePlacement));
                        piecePlacement.add(makeGreenPiece(), 2, 2);
                        gameBoard.addPiece(turn.getText(), 2, 2);
                        explanation.setText("G@C-3");
                        nextTurn();
                        break;
                    case "Yellow" :
                        piecePlacement.getChildren().remove(getNodeByRowColumnIndex(2, 2, piecePlacement));
                        piecePlacement.add(makeYellowPiece(), 2, 2);
                        gameBoard.addPiece(turn.getText(), 2, 2);
                        explanation.setText("Y@C-3");
                        nextTurn();
                        break;
                    case "Red" :
                        piecePlacement.getChildren().remove(getNodeByRowColumnIndex(2, 2, piecePlacement));
                        piecePlacement.add(makeRedPiece(), 2, 2);
                        gameBoard.addPiece(turn.getText(), 2, 2);
                        explanation.setText("R@C-3");
                        nextTurn();
                        break;
                }
            } else if (gameBoard.getSquare(2, 2) != null && gameBoard.pieceCount(turn.getText()) < 3) {
                switch (turn.getText()) {
                    case "Blue" : if (gameBoard.getSquare(1, 2) == null) {
                        gameBoard.addPiece("Blue", 1, 2);
                        Node node = getNodeByRowColumnIndex(1, 2, piecePlacement);
                        piecePlacement.getChildren().remove(node);
                        piecePlacement.add(makeBluePiece(), 2, 1);
                        explanation.setText("B@C-2");
                    } else if (gameBoard.pieceCount("Blue") == 0) {
                        int[] dice = rollDice();
                        if (gameBoard.capturePiece(dice[0], dice[1])) {
                            gameBoard.addPiece("Blue", 1, 2);
                            explanation.setText("BTC-2");
                        } else explanation.setText("BXC-2");
                    }
                        nextTurn();
                        break;
                    case "Green" : if (gameBoard.getSquare(2, 3) == null) {
                        gameBoard.addPiece("Green", 2, 3);
                        Node node = getNodeByRowColumnIndex(2, 3, piecePlacement);
                        piecePlacement.getChildren().remove(node);
                        piecePlacement.add(makeGreenPiece(), 3, 2);
                        explanation.setText("G@D-3");
                    } else if (gameBoard.pieceCount("Green") == 0) {
                        int[] dice = rollDice();
                        if (gameBoard.capturePiece(dice[0], dice[1])) {
                            gameBoard.addPiece("Green", 2, 3);
                            explanation.setText("GTD-3");
                        } else explanation.setText("GXD-3");
                    }
                        nextTurn();
                        break;
                    case "Yellow" : if (gameBoard.getSquare(3, 2) == null) {
                        gameBoard.addPiece("Yellow", 3, 2);
                        Node node = getNodeByRowColumnIndex(3, 2, piecePlacement);
                        piecePlacement.getChildren().remove(node);
                        piecePlacement.add(makeYellowPiece(), 2, 3);
                        explanation.setText("Y@C-4");
                    } else if (gameBoard.pieceCount("Yellow") == 0) {
                        int[] dice = rollDice();
                        if (gameBoard.capturePiece(dice[0], dice[1])) {
                            gameBoard.addPiece("Yellow", 3, 2);
                            explanation.setText("YTC-4");
                        } else explanation.setText("YXC-4");
                    }
                        nextTurn();
                        break;
                    case "Red" : if (gameBoard.getSquare(2, 1) == null) {
                        gameBoard.addPiece("Red", 2, 1);
                        Node node = getNodeByRowColumnIndex(2, 1, piecePlacement);
                        piecePlacement.getChildren().remove(node);
                        piecePlacement.add(makeRedPiece(), 1, 2);
                        explanation.setText("R@B-3");

                    } else if (gameBoard.pieceCount("Red") == 0) {
                        int[] dice = rollDice();
                        if (gameBoard.capturePiece(dice[0], dice[1])) {
                            gameBoard.addPiece("Red", 2, 1);
                            explanation.setText("RTB-3");
                        } else explanation.setText("RXB-3");
                    }
                        nextTurn();
                        break;
                }
            }
            moves.clear();
            piecePlacement.getChildren().removeAll(nPossibleMove, ePossibleMove, sPossibleMove, wPossibleMove);
        });


        //select and move piece event

        piecePlacement.setOnMouseClicked(event -> {
            //get the x and y coordinates
            double x = event.getX();
            double y = event.getY();
            if (moves.isEmpty()) {
                int startX = xCoordinate((int) x);
                int startY = yCoordinate((int) y);
                if (startX >= 0 && startX <= 4 && startY >= 0 && startY <= 4) {
                    //check to make sure a valid piece is at the square
                    try {
                        if (gameBoard.pieceLocation[startY][startX].pawnColor.equals(turn.getText()) &&
                        !(gameBoard.pieceLocation[startY][startX].isFlag)) {
                            moves.add(startX);
                            moves.add(startY);
                            if (startX > 0) piecePlacement.add(wPossibleMove,startX - 1, startY);
                            if (startX < 4) piecePlacement.add(nPossibleMove, startX + 1, startY);
                            if (startY > 0) piecePlacement.add(sPossibleMove, startX, startY - 1);
                            if (startY < 4) piecePlacement.add(ePossibleMove, startX, startY + 1);
                        }
                    } catch (NullPointerException exception) {
                        System.out.println("You can't move that piece");
                        moves.clear();
                    }
                }
            } else {
                int endX = xCoordinate((int) x);
                int endY = yCoordinate((int) y);
                if (endX >= 0 && endX <= 4 && endY >= 0 && endY <= 4) {

                    //change them to be used by the piecePlacement GridPane
                    moves.add(endX);
                    moves.add(endY);
                    int[] rolls = rollDice();

                    // get the dice numbers
                    int dice1 = rolls[0];
                    int dice2 = rolls[1];

                    //update dice if necessary
                    boolean captureCheck = false;
                    if (gameBoard.pieceLocation[moves.get(3)][moves.get(2)] != null &&
                            gameBoard.pieceLocation[moves.get(3)][moves.get(2)].isPawn) {
                        captureCheck = true;
                        die1.setText(dice1 + "");
                        die2.setText(dice2 + "");

                        String letter = getRowLetter(moves.get(2));
                        String number = getColumnNumber(moves.get(3));
                        String shortHand = getShortHandColor();

                        if (gameBoard.capturePiece(dice1, dice2)) explanation.setText(shortHand + "T" +
                                letter + "-" + number);
                        else explanation.setText(shortHand + "X" + letter + "-" + number);
                    }

                    // move on the array board
                    if (gameBoard.movePiece(gameBoard.pieceLocation[moves.get(1)][moves.get(0)],
                            moves.get(1), moves.get(0), moves.get(3), moves.get(2), dice1, dice2)) {
                        String letter = getRowLetter(moves.get(2));
                        String number = getColumnNumber(moves.get(3));
                        if (!(captureCheck)) explanation.setText(getShortHandColor() + letter + "-" + number);

                        // clear the board!
                        piecePlacement.getChildren().clear();
                        piecePlacement.add(makeFakeInset(), 5, 0);
                        piecePlacement.add(placePieceButton, 6, 0);
                        for (int i = 0; i < 5; i++) {
                            for (int j = 0; j < 5; j++) {
                                if (gameBoard.pieceLocation[i][j] != null) {
                                    if (gameBoard.pieceLocation[i][j].isPawn ||
                                            gameBoard.pieceLocation[i][j].isPawnWithFlag) {
                                        String pawnColor = gameBoard.pieceLocation[i][j].getPawnColor();
                                        switch (pawnColor) {
                                            case "Blue":
                                                piecePlacement.add(makeBluePiece(), j, i);
                                                if (gameBoard.getSquare(i, j).isPawnWithFlag)
                                                    if (gameBoard.pieceLocation[i][j].getFlagColor().equals("Green")) {
                                                        piecePlacement.add(makeGreenFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Yellow")) {
                                                        piecePlacement.add(makeYellowFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Red")) {
                                                        piecePlacement.add(makeRedFlag(), j, i);
                                                    }
                                                break;

                                            case "Green":
                                                piecePlacement.add(makeGreenPiece(), j, i);
                                                if (gameBoard.getSquare(i, j).isPawnWithFlag)
                                                    if (gameBoard.pieceLocation[i][j].getFlagColor().equals("Blue")) {
                                                        piecePlacement.add(makeBlueFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Yellow")) {
                                                        piecePlacement.add(makeYellowFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Red")) {
                                                        piecePlacement.add(makeRedFlag(), j, i);
                                                    }
                                                break;

                                            case "Yellow":
                                                piecePlacement.add(makeYellowPiece(), j, i);
                                                if (gameBoard.getSquare(i, j).isPawnWithFlag)
                                                    if (gameBoard.pieceLocation[i][j].getFlagColor().equals("Blue")) {
                                                        piecePlacement.add(makeBlueFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Green")) {
                                                        piecePlacement.add(makeGreenFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Red")) {
                                                        piecePlacement.add(makeRedFlag(), j, i);
                                                    }
                                                break;

                                            case "Red":
                                                piecePlacement.add(makeRedPiece(), j, i);
                                                if (gameBoard.getSquare(i, j).isPawnWithFlag)
                                                    if (gameBoard.pieceLocation[i][j].getFlagColor().equals("Blue")) {
                                                        piecePlacement.add(makeBlueFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Green")) {
                                                        piecePlacement.add(makeGreenFlag(), j, i);
                                                    } else if
                                                    (gameBoard.pieceLocation[i][j].getFlagColor().equals("Yellow")) {
                                                        piecePlacement.add(makeYellowFlag(), j, i);
                                                    }
                                                break;
                                        }
                                    } else if (gameBoard.pieceLocation[i][j].isFlag) {
                                        String flagColor = gameBoard.pieceLocation[i][j].getFlagColor();
                                        switch (flagColor) {
                                            case "Blue":
                                                piecePlacement.add(makeBlueFlag(), j, i);
                                                break;

                                            case "Green":
                                                piecePlacement.add(makeGreenFlag(), j, i);
                                                break;

                                            case "Yellow":
                                                piecePlacement.add(makeYellowFlag(), j, i);
                                                break;

                                            case "Red":
                                                piecePlacement.add(makeRedFlag(), j, i);
                                                break;
                                        }
                                    }
                                } else {
                                    piecePlacement.add(makePlaceHolder(), j, i);
                                }
                            }
                        }
                        moves.clear();
                        nextTurn();
                        piecePlacement.getChildren().removeAll(nPossibleMove, ePossibleMove,
                                sPossibleMove, wPossibleMove);

                    } else {
                        moves.clear();
                        piecePlacement.getChildren().removeAll(nPossibleMove, ePossibleMove,
                                sPossibleMove, wPossibleMove);
                        explanation.setText("");
                    }
                }
            }
        });

        gameBoardDisplay.add(playersButton4, 6, 4);
        gameBoardDisplay.add(playersButton2, 7, 4);

        //pane alignments
        gameBoardDisplay.setAlignment(Pos.CENTER);
        piecePlacement.setAlignment(Pos.CENTER);

        //master pane
        Pane pane = new Pane(gameBoardDisplay, piecePlacement);
        pane.setSnapToPixel(true);
        pane.setPadding(new Insets(15));

        //display scene
        Scene scene = new Scene(pane, 700, 500);
        primaryStage.setTitle("Capture the Flag");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @return a new Rectangle Class object, it's size is 80 by 80, and it has a light brown color
     */
    public Rectangle makeLightSquare() {return new Rectangle(80, 80, Color.SANDYBROWN);}

    /**
     * @return a new Rectangle Class object, it's size is 80 by 80, and it has a dark brown color
     */
    public Rectangle makeDarkSquare() {return new Rectangle(80, 80, Color.SADDLEBROWN);}

    /**
     * @return a new Rectangle Class object, it's size is 80 by 80, and it has a blue color. The code only calls
     * for this Rectangle only once
     */
    public Rectangle makeBlueSquare() {return new Rectangle(80, 80, Color.BLUE);}

    /**
     * @return a new Rectangle Class object, it's size is 80 by 80, and it has a blue color. The code only calls
     * for this Rectangle only once.
     */
    public Rectangle makeGreenSquare() {return new Rectangle(80, 80, Color.GREEN);}

    /**
     * @return a new Rectangle Class object, it's size is 80 by 80, and it has a yellow color. The code only calls
     * for this Rectangle only once.
     */
    public Rectangle makeYellowSquare() {return new Rectangle(80, 80, Color.GOLD);}

    /**
     * @return a new Rectangle Class object, it's size is 80 by 80, and it has a yellow color. The code only calls
     * for this Rectangle only once.
     */
    public Rectangle makeRedSquare() {return new Rectangle(80, 80, Color.RED);}

    /**
     * @return a new Rectangle Class object, it's size is 60 by 60 and is half of the dice seen on screen.
     * It is only the main light gray body without the text
     */
    public Rectangle makeDice() {
        Rectangle dice = new Rectangle(60, 60, Color.LIGHTGRAY);
        dice.setStrokeWidth(2);
        dice.setStroke(Color.BLACK);
        return dice;
    }

    /**
     * @return a new Rectangle with 0 opacity, It is used to mimic an inset so there is spacing between the numbers on
     * the right side of the column of the game board do not overlap and have some breathing room between them.
     */
    public Rectangle makeFakeInset() {
        Rectangle rectangle = new Rectangle(40, 30);
        rectangle.setOpacity(0);
        return rectangle;
    }

    /**
     * @return a new Circle Class object, the object is blue with a black border, to fill up a total diameter of 40
     */
    public Circle makeBluePiece() {
        Circle circle = new Circle(38.5, Color.DODGERBLUE);
        circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(3);
        return circle;
    }

    /**
     * @return a new Circle Class object, the object is green with a black border, to fill up a total diameter of 40
     */
    public Circle makeGreenPiece() {
        Circle circle = new Circle(38.5, Color.FORESTGREEN);
        circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(3);
        return circle;
    }

    /**
     * @return a new Circle Class object, the object is green with a black border, to fill up a total diameter of 40
     */
    public Circle makeYellowPiece() {
        Circle circle = new Circle(38.5, Color.YELLOW);
        circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(3);
        return circle;
    }

    /**
     * @return a new Circle Class object, the object is red with a black border, to fill up a total diameter of 40
     */
    public Circle makeRedPiece() {
        Circle circle = new Circle(38.5, Color.ORANGERED);
        circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(3);
        return circle;
    }

    /**
     * @return a new Circle Class object, the object has an opacity of 0, this allows this piece to hold the
     * gridPaneDisplay data field to not shrink as pieces are moved throughout the grid
     */
    public Circle makePlaceHolder() {
        Circle circle = new Circle(40);
        circle.setOpacity(0);
        return circle;
    }

    /**
     * @return a new Circle Class object, the object has an opacity of .5, it is used to show where the players
     * may move any given piece.
     */
    public Circle makePossibleMove() {
        Circle circle = new Circle(40, Color.LIGHTGRAY);
        circle.setOpacity(.5);
        return circle;
    }

    /**
     * @return a Polygon Class object that resembles a flag, the object is blue to signify which team's flag it is.
     */
    public Polygon makeBlueFlag() {
        Polygon flag = new Polygon(0, 0, 0, 70, 15, 70, 15, 35, 45, 20);
        flag.setFill(Color.DODGERBLUE);
        flag.setStroke(Color.BLACK);
        flag.setStrokeWidth(3);
        return flag;
    }

    /**
     * @return a Polygon Class object that resembles a flag, the object is green to signify which team's flag it is.
     */
    public Polygon makeGreenFlag() {
        Polygon flag = new Polygon(0, 0, 0, 70, 15, 70, 15, 35, 45, 20);
        flag.setFill(Color.FORESTGREEN);
        flag.setStroke(Color.BLACK);
        flag.setStrokeWidth(3);
        return flag;
    }

    /**
     * @return a Polygon Class object that resembles a flag, the object is yellow to signify which team's flag it is
     */
    public Polygon makeYellowFlag() {
        Polygon flag = new Polygon(0, 0, 0, 70, 15, 70, 15, 35, 45, 20);
        flag.setFill(Color.YELLOW);
        flag.setStroke(Color.BLACK);
        flag.setStrokeWidth(3);
        return flag;
    }

    /**
     * @return a Polygon Class object that resembles a flag, the object is red to signify which team's flag it is
     */
    public Polygon makeRedFlag() {
        Polygon flag = new Polygon(0, 0, 0, 70, 15, 70, 15, 35, 45, 20);
        flag.setFill(Color.ORANGERED);
        flag.setStroke(Color.BLACK);
        flag.setStrokeWidth(3);
        return flag;
    }

    /**
     * @return a Label, this is the second half of the dice seen on screen containing the number that is inside. When
     * the code is loaded it defaults to the number 1
     */
    public Label makeDiceLabel() {
        Label label = new Label("1");
        label.setPadding(new Insets(0, 0, 0, 20));
        label.setFont(new Font(45));
        return label;
    }

    /**
     * @param row a positive integer, for this project specifically it uses the range 0-5, to identify what row any
     *           given node is in the piecePlacement data field
     * @param column a positive integer, for this project specifically it uses the range 0-5, to identify what
     *              column any given node is in the piecePlacement data field
     * @param gridPane any GridPane object will work, but this project uses the piecePlacement GridPane to obtain
     *                the node at its row and column coordinate
     * @return a Node Class Object, for this project the node is one of the Circle Pieces. If no piece exists,
     * the method returns null
     */
    public Node getNodeByRowColumnIndex (final int row, final int column, GridPane gridPane) {
        Node result = null;
        ObservableList<Node> children = gridPane.getChildren();

        for (Node node : children) {
            if (GridPane.getRowIndex(node) == row && GridPane.getColumnIndex(node) == column) {
                result = node;
                break;
            }
        }
        return result;
    }

    /**
     * @return an array containing two int values between 1 and 6 to represent the dice rolled inside the game.
     */
    public int[] rollDice() {
        int[] rolls = new int[2];
        rolls[0] = (int) (Math.random() * 6 + 1);
        rolls[1] = (int) (Math.random() * 6 + 1);
        return rolls;
    }

    /**
     * @param x any positive int value. This project uses digits between 0 and 358.
     * @return a value between 0 and 4 to represent a specific row when the method is called.
     */
    public int xCoordinate(int x) {
        if (x < 118) x = 0;
        else if (x > 124 && x < 196) x = 1;
        else if (x > 198 && x < 278) x = 2;
        else if (x > 280 && x < 356) x = 3;
        else if (x > 358) x = 4;
        return x;
    }

    /**
     * @param y any positive int value. This project uses digits between 0 and 360.
     * @return a value between 0 and 4 to represent a specific column when the method is called.
     */
    public int yCoordinate(int y) {
        if (y < 116) y = 0;
        else if (y > 120 && y < 198) y = 1;
        else if (y > 202 && y < 278) y = 2;
        else if (y > 282 && y < 358) y = 3;
        else if (y > 360) y = 4;
        return y;
    }

    /**
     * @param row any int digit between 0 and 4.
     * @return a letter representing the value inputted.
     */
    public String getRowLetter(int row) {
        switch (row) {
            case 0 : return "A";
            case 1 : return "B";
            case 2 : return "C";
            case 3 : return "D";
            case 4 : return "E";
        }
        return null;
    }

    /**
     * @param column any int value between 0 and 4.
     * @return the column value inserted plus 1
     */
    public String getColumnNumber(int column) {
        return String.valueOf(column + 1);
    }

    /**
     * @return a value based on the turn Label's text, Y for Yellow, R for Red, B for Blue, and G for Green
     */
    public String getShortHandColor() {
        switch (turn.getText()) {
            case "Blue" : return "B";
            case "Green" : return "G";
            case "Yellow" : return "Y";
            case "Red" : return "R";
        }
        return null;
    }

    /**
     * @param label any label, this method gives the label insets and a font
     */
    public void setFontRow(Label label) {
        label.setFont(new Font(15));
        label.setPadding(new Insets(15, 0, 0, 30));
    }

    /**
     * @param label any label, this method gives the label insets and a font
     */
    public void setFontColumn(Label label) {
        label.setFont(new Font(15));
        label.setPadding(new Insets(13, 15, 0, 15));
    }

    /**
     * Checks the gameBoard data field for the next flag, if it is found it goes to the next player skipping
     * any missing flags until there is only one. When this happens the explanation data field is updated to
     * display the winner of the game
     */
    public void nextTurn() {
        switch (turn.getText()) {
            case "Yellow" :
                if (gameBoard.getFlag("Red")) {turn.setText("Red");}
                else if (gameBoard.getFlag("Blue")) {turn.setText("Blue");}
                else if (gameBoard.getFlag("Green")) {turn.setText("Green");}
                else {explanation.setText("Yellow Wins!"); turn.setText(""); UITurn.setText("");}
                break;
            case "Red" :
                if (gameBoard.getFlag("Blue")) {turn.setText("Blue");}
                else if (gameBoard.getFlag("Green")) {turn.setText("Green");}
                else if (gameBoard.getFlag("Yellow")) {turn.setText("Yellow");}
                else {explanation.setText("Red Wins!"); turn.setText(""); UITurn.setText("");}
                break;
            case "Blue" :
                if (gameBoard.getFlag("Green")) {turn.setText("Green");}
                else if (gameBoard.getFlag("Yellow")) {turn.setText("Yellow");}
                else if (gameBoard.getFlag("Red")) {turn.setText("Red");}
                else {explanation.setText("Blue Wins!"); turn.setText(""); UITurn.setText("");}
                break;
            case "Green" :
                if (gameBoard.getFlag("Yellow")) {turn.setText("Yellow");}
                else if (gameBoard.getFlag("Red")) {turn.setText("Red");}
                else if (gameBoard.getFlag("Blue")) {turn.setText("Blue");}
                else {explanation.setText("Green Wins!"); turn.setText(""); UITurn.setText("");}
                break;
        }
    }

    /**
     * @param gridPane any GridPane, in the case of this project it uses the gameBoard variable inside the
     *                start method. It places tiles alternating between the methods, makeDarkSquare()
     *                and makeLightSquare(). Placing colored tiles when necessary.
     */
    public final void setBoard(GridPane gridPane) {
        gridPane.addRow(0, makeDarkSquare(), makeLightSquare(), makeBlueSquare(),
                makeLightSquare(), makeDarkSquare());
        gridPane.addRow(1, makeLightSquare(), makeDarkSquare(), makeLightSquare(),
                makeDarkSquare(), makeLightSquare());
        gridPane.addRow(2, makeRedSquare(), makeLightSquare(), makeDarkSquare(),
                makeLightSquare(), makeGreenSquare());
        gridPane.addRow(3, makeLightSquare(), makeDarkSquare(), makeLightSquare(),
                makeDarkSquare(), makeLightSquare());
        gridPane.addRow(4, makeDarkSquare(), makeLightSquare(), makeYellowSquare(),
                makeLightSquare(), makeDarkSquare());
    }

    /**
     * @param args This method is only required for compilation. It serves no further purpose.
     */
    public static void main(String[] args) {launch();}
}